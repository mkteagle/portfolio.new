(function(){
  'use strict';

  // Prepare the 'lists' module for subsequent registration of controllers and delegates
  angular.module('lists', [ 'ngMaterial', 'navController' ]);


})();
